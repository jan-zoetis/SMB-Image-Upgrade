# ============================ Driver Version ============================= #
# =                                                                       = #
# =                          EETI eGTouch driver                          = #
# =                                                                       = #
# = eGTouchD version: 2.5                                                 = #
# = eGTouchU version: 1.4                                                 = #
# =                                           released date: 2017/07/17   = #
# =                                           support: touch_fae@eeti.com = #
# ========================================================================= #


# ========================= Install Guide ================================= #

Please open the document "EETI_eGTouch_Programming_Guide" 
under the Guide directory, and follow the Guidline to install driver.
	
# ========================================================================= #